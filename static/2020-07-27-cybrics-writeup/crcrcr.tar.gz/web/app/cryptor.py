import sys
import os
import random
import ast

class RC4:
    def __init__(self, key):
        S = list(range(0x100))
        j = 0
        for i in range(0x100):
            j = (S[i] + key[i % len(key)] + j) & 0xff
            S[i], S[j] = S[j], S[i]
        self.S = S
        self.keystream = self._keystream_generator()

    def crypt_file(self, data):
        res = []
        while (i := data.read(1)):
            res.append(ord(i) ^ next(self.keystream))
        return bytes(res)

    def crypt_string(self, data):
        res = []
        for i in data:
            res.append(ord(i) ^ next(self.keystream))
        return bytes(res)

    def _keystream_generator(self):
        x = y = 0
        while True:
            x = (x + 1) & 0xff
            y = (self.S[x] + y) & 0xff
            self.S[x], self.S[y] = self.S[y], self.S[x]
            i = (self.S[x] + self.S[y]) & 0xff
            yield self.S[i]


if __name__ == "__main__":
    rc4_key = os.urandom(1024)
    cipher = RC4(rc4_key)
    del rc4_key
    data = open(sys.argv[1], "rb")
    res = cipher.crypt_file(data)
    f = open("res2.bin", "wb")
    f.write(res)
    f.close()
    del data
    K1 = [random.randrange(0, 256, 1) for i in range(256)] 
    K2 = [random.randrange(0, 256, 1) for i in range(256)] 
    K3 = [random.randrange(0, 256, 1) for i in range(256)] 
    K4 = [random.randrange(0, 256, 1) for i in range(256)] 
    K5 = [random.randrange(0, 256, 1) for i in range(256)] 
    K6 = [random.randrange(0, 256, 1) for i in range(256)] 
    user_input = input()
    enc_dict = ast.literal_eval(user_input)
    to_encrypt = enc_dict['to_enc']
    if enc_dict['need_enc'] == 1:
        output = open("user.enc", "wb")
        encrypted = cipher.crypt_string(to_encrypt)
        output.write(output)
        output.close()
    else:
        output = open("user.enc", "wb")
        output.write(to_encrypt)
        output.close()
    