from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired

class CreateForm(FlaskForm):
    user_data = StringField('User Data', validators=[DataRequired()])
    submit = SubmitField('Get my files')
