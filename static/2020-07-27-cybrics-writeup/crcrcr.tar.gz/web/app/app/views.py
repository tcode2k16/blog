from flask import render_template, flash, redirect,url_for, request, session, send_file
from Crypto.Cipher import ARC4
from app import app
from app.forms import CreateForm
import hashlib
import os

root_dir = "/app"

@app.route('/')
@app.route('/index')
def index():
    form = CreateForm()
    return render_template('home.html', title='Make your try', form=form)

@app.route('/get_files', methods=['GET', 'POST'])
def login():
    form = CreateForm()
    try:
        foldername = f"data/upload/{hashlib.sha1(os.urandom(32)).hexdigest()}"

        curr_dir = os.getcwd()
        os.mkdir(foldername)
        os.chdir(foldername)
        input_file = open("input", "w")
        input_file.write(form.user_data.data)
        input_file.close()
        os.system("echo 0x3f > /proc/self/coredump_filter && python3.8 %s/cryptor.py %s/flag.png < input" % (curr_dir, curr_dir))
        os.system("rm input")
        files = filter(lambda x: os.path.isfile(x), os.listdir('.'))
        lst = [f"{foldername}/{x}" for x in files]        

    except Exception as e:
        print(e)
        os.chdir(root_dir)
        foldername = "Error!"
        return redirect(url_for('index'))
    os.chdir(root_dir)
    for i in lst:
        data_file = open(i, "rb")
        data = data_file.read()
        data_file.close()
        data_file = open(i, "wb")
        cipher = ARC4.new(app.config['RC4_KEY'])
        data = cipher.encrypt(data)
        data_file.write(data)
        data_file.close()
    return render_template('files.html', title='Link', fn = lst)


from flask import send_from_directory

@app.route('/data/<path:filename>')
def serve_static(filename):
    
    return send_file(os.path.join(root_dir,"data", filename))