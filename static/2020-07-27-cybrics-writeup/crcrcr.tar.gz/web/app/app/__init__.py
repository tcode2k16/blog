from flask import Flask
import os
app = Flask(__name__)
app.config['SECRET_KEY'] = 'NOT_REAL'
app.config['RC4_KEY'] = b'NOT_REAL'
from app import views
