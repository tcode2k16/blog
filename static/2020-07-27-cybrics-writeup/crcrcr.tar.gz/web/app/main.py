from app import app as a

app = a

if __name__ == "__main__":
    app.run(host='0.0.0.0')